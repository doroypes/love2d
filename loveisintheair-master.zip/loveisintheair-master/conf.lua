function love.conf(t)
  t.window.fullscreen = false
  t.window.resizable = true
  t.window.width = 800
  t.window.height = 600
  t.window.msaa = 2
  t.window.title = "Love Is In The Air"
end
